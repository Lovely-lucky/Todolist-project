package com.fullstack.todomanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodomanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodomanagementApplication.class, args);
	}

}
